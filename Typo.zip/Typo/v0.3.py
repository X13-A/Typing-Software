#To do: score point
#       error memory/learning
#       menu touchsc reen support
#       better UI (main menu, colors)
#       sounds fx
#       stats img reset
#       settings menu


import pygame
import pygame.freetype
import sys
import os
from os import path
import random
import time
from pygame.locals import *
from FR import *
from pygame._sdl2.video import Window

WHITE      = (255,255,255)
LIGHTGREY  = (230,230,230)
BLACK      = (0,0,0)
BARGREY    = (33,37,43)
HIGHLIGHT  = (44,49,60)
DARKGREY   = (40,44,52)
GREY       = (63,67,73)
FONTWHITE  = (171,178,191)
FONTRED    = (224,108,117)
FONTBLUE   = (97,175,239)
FONTGREEN  = (152,195,121)
FONTPURPLE = (198,120,221)
MAXFPS     = 60

class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()
        self.clock = pygame.time.Clock()
        self.timer = time.time()
        self.width = 800
        self.height = 640
        self.fullscreen = False
        self.display_info = pygame.display.Info()
        self.screen = pygame.display.set_mode((self.width, self.height,),RESIZABLE)
        self.window = Window.from_display_module()
        self.w, self.h = pygame.display.get_surface().get_size()
        self.subscreen = pygame.Surface((self.w, self.h))
        self.spacement = 3
        self.cursor = pygame.Surface((3, 40))
        self.cursor_alpha = 255
        self.cursor_x = 40 + self.spacement - self.cursor.get_width()
        self.cursor_pos = 0
        self.plusalpha = -10
        self.gamemode = 'FR'
        self.theme = "Grey"
        self.bgcolor = DARKGREY
        self.textcolor = FONTWHITE
        self.statcolor = FONTRED
        self.selectcolor = FONTGREEN
        self.typedcolor = GREY
        self.cursor_color = FONTBLUE
        self.font = pygame.freetype.Font('pokemon.tff', 40)
        self.max_chars = 38
        self.mouse_pos = pygame.mouse.get_pos()
        self.chars = ['a','z','e','r','t','y','u','i','o','p','q','s','d',
                      'f','g','h','j','k','l','m','w','x','c','v','b','n'] #,'é','è','à','â','ê','û','ù']
        self.paused = True
        self.in_menu = True
        self.keys_score = 0
        self.errors_score = 0
        self.words_score = 0
        self.ACC = 100
        self.KPM = 0
        self.WPM = 0
        self.time_elapsed = 0
        self.KPM_str = ''.join([str(int(self.KPM))," cpm"])
        self.WPM_str = ''.join([str(int(self.WPM))," wpm"])
        self.ACC_str = ''.join([str(int(self.ACC)),"%"," acc"])
        self.start_clicked = False
    def start_menu(self):
        Select_gamemode = self.font.render_to(self.subscreen, (100, 320), 'Select gamemode:', (self.textcolor))
        Select_theme = self.font.render_to(self.subscreen, (100, 100), 'Select theme:', (self.textcolor))

        Start = self.font.render_to(self.subscreen, (100, 500), 'Start', (self.textcolor))
        Start.topleft = (100, 500)
        keys = pygame.key.get_pressed()
        click = pygame.mouse.get_pressed() == (1,0,0)
        FR = pygame.Rect(0, 0, 0, 0)
        Hard =  pygame.Rect(0, 0, 0, 0)
        Letters = pygame.Rect(0, 0, 0, 0)
        if self.gamemode == 'FR':
            FR = self.font.render_to(self.subscreen, (100, 360), 'French', (self.typedcolor))
        else:
            FR = self.font.render_to(self.subscreen, (100, 360), 'French', (self.textcolor))
        if self.gamemode == 'Letters':
            Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.typedcolor))
        else:
            Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.textcolor))
        if self.gamemode == 'Hard':
            Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.typedcolor))
        else:
            Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.textcolor))

        if self.theme == 'Grey':
            Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.typedcolor))
        else:
            Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.textcolor))
        if self.theme == 'Dark':
            Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.typedcolor))
        else:
            Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.textcolor))
        if self.theme == 'Bright':
            Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.typedcolor))
        else:
            Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.textcolor))

        FR.topleft = (100,360)
        Hard.topleft = (100,400)
        Letters.topleft = (100, 440)
        Grey.topleft = (100, 140)
        Dark.topleft = (100, 180)
        Bright.topleft = (100, 220)

        buttons = [FR, Hard, Letters, Grey, Dark, Bright, Start]

        for button in buttons:
            if button.collidepoint((self.mouse_pos[0] / self.scale[0], self.mouse_pos[1] / self.scale[1])):
                if button == FR:
                    FR = self.font.render_to(self.subscreen, (100, 360), 'French', (self.selectcolor))
                    if click:
                        FR = self.font.render_to(self.subscreen, (100, 360), 'French', (self.typedcolor))
                        new_mode = 'FR'
                        self.gamemode = new_mode
                if button == Hard:
                    Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.selectcolor))
                    if click:
                        Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.typedcolor))
                        new_mode = 'Hard'
                        self.gamemode = new_mode
                if button == Letters:
                    Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.selectcolor))
                    if click:
                        Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.typedcolor))
                        new_mode = 'Letters'
                        self.gamemode = new_mode
                if button == Grey:
                    Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.selectcolor))
                    if click:
                        Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.typedcolor))
                        self.theme = 'Grey'
                if button == Dark:
                    Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.selectcolor))
                    if click:
                        Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.typedcolor))
                        self.theme = 'Dark'
                if button == Bright:
                    Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.selectcolor))
                    if click:
                        Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.typedcolor))
                        self.theme = 'Bright'
                if button == Start:
                    Start = self.font.render_to(self.subscreen, (100, 500), 'Start', (self.selectcolor))
                    if click:
                        self.start_clicked = True
                        Start = self.font.render_to(self.subscreen, (100, 500), 'Start', (self.typedcolor))
                    if not click and self.start_clicked:
                        self.new_list()
                        self.start_clicked = False
                        self.in_menu = False

    def themes(self):
            if self.theme == 'Bright':
                self.textcolor = GREY
                self.statcolor = GREY
                self.typedcolor = LIGHTGREY
                self.selectcolor = FONTBLUE
                self.bgcolor = WHITE
                self.cursor_color = FONTBLUE
            if self.theme == "Dark":
                self.textcolor = WHITE
                self.statcolor = WHITE
                self.typedcolor = GREY
                self.selectcolor = FONTRED
                self.bgcolor = BLACK
                self.cursor_color = WHITE
            if self.theme == "Grey":
                self.textcolor = FONTWHITE
                self.statcolor = FONTRED
                self.typedcolor = GREY
                self.selectcolor = FONTGREEN
                self.bgcolor = DARKGREY
                self.cursor_color = FONTBLUE

    def stats_reset(self):
        self.paused = True
        self.keys_score = 0
        self.errors_score = 0
        self.words_score = 0
        self.ACC = 100
        self.KPM = 0
        self.WPM = 0
        self.time_elapsed = 0
        self.cursor_x = 40 + self.spacement - self.cursor.get_width()
        self.cursor_pos = 0

    def new_list(self):
        self.words_list = []
        if self.gamemode == 'FR':
            for i in range(10):
                word = random.choice(FR_WORDS)
                self.max_chars = 38
                if len(list(' '.join(self.words_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.words_list.append(word)
            self.words_str = ' '.join(self.words_list) #error
            self.words_list = list(self.words_str)
            self.words_list.append(' ')
            self.spacement = 3

        if self.gamemode == 'Letters':
            self.max_chars = 20
            for i in range(self.max_chars):
                letter = random.choice(self.chars)
                self.words_list.append(letter)
            self.words_str = ''.join(self.words_list)
            self.spacement = 20

        if self.gamemode == 'Hard':
            for i in range(10):
                word = ''.join(random.sample(self.chars, k = random.randint(1,8)))
                self.max_chars = 38
                if len(list(' '.join(self.words_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.words_list.append(word)
            self.words_str = ' '.join(self.words_list) #error
            self.words_list = list(self.words_str)
            self.words_list.append(' ')
            self.spacement = 3

        self.words_len = len(self.words_list)
        self.cursor_pos = 0
        self.cursor_x = 40 + self.spacement - self.cursor.get_width()

    def stats(self):
        if self.paused:
            self.timer = time.time()
            self.time_left = 60
        if not self.paused:
            self.time_elapsed = time.time() - self.timer
            self.time_left = 60 - self.time_elapsed
            if self.time_elapsed != 0:
                self.KPM = (self.keys_score / self.time_elapsed) * 60
                self.WPM = (self.words_score / self.time_elapsed) * 60
        if (self.keys_score + self.errors_score) >= 1:
            self.ACC = (self.keys_score/(self.keys_score + self.errors_score)) * 100

        if self.time_left <= 0:
            self.stats_reset()
            self.new_list()
        else:
            if not self.paused:
                self.KPM_str = ''.join([str(int(self.KPM))," cpm"])
                self.WPM_str = ''.join([str(int(self.WPM))," wpm"])
                self.ACC_str = ''.join([str(int(self.ACC)),"%"," acc"])

    def get_scale(self):
        self.scale = self.screen.get_size()[0] / self.width, self.screen.get_size()[1] / self.height

    def update(self):
            pygame.display.flip()
            self.subscreen.fill(self.bgcolor)
            actual_fps = self.clock.get_fps()
            pygame.display.set_caption(str(actual_fps))
            self.dt = self.clock.tick(MAXFPS)
            self.mouse_pos = pygame.mouse.get_pos()
            if not self.in_menu:
                if self.cursor_alpha >= 255:
                    self.plusalpha = -10
                if self.cursor_alpha <= 0:
                    self.plusalpha = 10
                self.cursor_alpha += self.plusalpha * (self.dt /17)
                if self.cursor_pos == len(self.words_list):
                    self.words_score += 1
                    self.new_list()
                    if self.time_elapsed != 0:
                        self.WPM = (self.words_score / self.time_elapsed) * 60

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if not self.in_menu:
                        self.stats_reset()
                        self.in_menu = True
                    else:
                        pygame.quit()
                if not self.in_menu:
                    if event.unicode == self.words_list[self.cursor_pos]:
                        if self.paused:
                            self.paused = False
                        img, rect = self.font.render(self.words_list[self.cursor_pos], (self.textcolor))
                        self.cursor_x += img.get_width() + self.spacement
                        self.cursor_pos += 1
                        self.cursor_alpha = 255
                        self.keys_score += 1

                        if event.unicode == ' ':
                            self.words_score += 1
                    else:
                        if not self.paused:
                            self.errors_score += 1
                            self.cursor_alpha = 255

                elif event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.w = self.display_info.current_w
                        self.h = self.display_info.current_h
                        self.window.position = 0,0
                        self.screen = pygame.display.set_mode((self.w, self.h),NOFRAME)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.w, self.h = self.width, self.height
                        self.screen = pygame.display.set_mode((self.width, self.height,),RESIZABLE)
                        self.window.position = 50,50

            if event.type == pygame.VIDEORESIZE:
                scrsize = event.size
                self.w   = event.w
                self.h   = event.h
                self.screen = pygame.display.set_mode(scrsize,RESIZABLE)

    def draw(self):
        lenght = 40
        for i in range(len(self.words_list)):
            if self.cursor_pos > i:
                color = self.typedcolor
            else:
                color = self.textcolor
            img, rect = self.font.render(self.words_list[i], (color))
            char_w = img.get_width()
            char_h = img.get_height()
            lenght += char_w + self.spacement
            if self.words_list[i] in ('g','j','p','q','y','ç'):
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 35 - char_h ))
            else:
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 29 - char_h ))

        self.cursor.fill(self.cursor_color)
        self.cursor.set_alpha(self.cursor_alpha)
        self.subscreen.blit(self.cursor,(self.cursor_x, (self.subscreen.get_height()//2)-3))
        self.KPM_img = self.font.render_to(self.subscreen, (40,40), self.KPM_str, (self.statcolor), size=0)
        if self.gamemode != 'Letters':
            self.WPM_img = self.font.render_to(self.subscreen, (40,80), self.WPM_str, (self.statcolor), size=0)
        self.ACC_img = self.font.render_to(self.subscreen, (40,120), self.ACC_str, (self.statcolor), size=0)
        self.time_img = self.font.render_to(self.subscreen, (40,160), str(round(self.time_left, 2)), (self.statcolor), size=0)
        self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))

    def loop(self):
        while True:
            self.get_scale()
            self.themes()
            self.update()
            self.events()
            if not self.in_menu:
                self.stats()
                self.draw()
            else:
                self.start_menu()
                self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))
g = Game()
while True:
    g.loop()
