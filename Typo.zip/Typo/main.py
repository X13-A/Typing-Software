#To do: score point
#       error memory/learning
#       menu touchscreen support
#       better UI (main menu, colors)
#       sounds fx
#       settings menu
#       goal bar
#       replay menu bars
#       custom colors
#       fix function key making spaces
#       clicker game

import pygame
import pygame.freetype
import sys
import os
from os import path
import random
import time
from PIL import Image, ImageFilter
from pygame.locals import *
from FR import *
import pickle
import win32api
import win32con
import win32gui

ATOM       = (33,37,43)
COLORKEY   = (18,18,18)
WHITE      = (255,255,255)
LIGHTGREY  = (230,230,230)
BLACK      = (0,0,0)
BARGREY    = (33,37,43)
HIGHLIGHT  = (44,49,60)
DARKGREY   = (40,44,52)
GREY       = (63,67,73)
FONTWHITE  = (171,178,191)
FONTRED    = (224,108,117)
FONTBLUE   = (97,175,239)
FONTGREEN  = (152,195,121)
FONTPURPLE = (198,120,221)
CLEAR = (255, 0, 128)  # Transparency color
MAXFPS     = 60

class Background(pygame.sprite.DirtySprite):
    def __init__(self, game, w, h, img):
        self.groups = game.permasprites
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.image = pygame.transform.scale(img, (self.game.width, self.game.height))
        self.rect = self.image.get_rect()
        self.alpha = 200

        strFormat = 'RGBA'
        raw_str = pygame.image.tostring(self.image, strFormat, False)
        pil_blured = Image.frombytes(strFormat, self.image.get_size(), raw_str).filter(ImageFilter.GaussianBlur(radius=4))

        blured = pygame.image.fromstring(pil_blured.tobytes("raw", 'RGBA'), (self.game.width,self.game.height), 'RGBA')
        self.image = blured
        #n_raw_str = pil_img.tostring("raw", strFormat)
        #surface = pygame.image.fromstring(n_raw_str, image.size, strFormat)

        self.blurcolor = (BLACK)
        self.surface = pygame.Surface((self.rect.width, self.rect.height))
        self.surface.fill(self.blurcolor)
        self.surface.set_alpha(self.alpha)
        self.image.blit(self.surface, [0,0])
    def update(self):
        self.dirty = 1

class Speed_bar(pygame.sprite.DirtySprite):
    def __init__(self, game):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.width = 700
        self.height = 25
        self.surface= pygame.Surface((self.width, self.height))
        self.surface.fill(COLORKEY)
        self.surface.set_colorkey(COLORKEY)
        self.image = self.surface
        self.rect = self.image.get_rect()
        self.rect.center = (self.game.width/2, 560)
        self.percent = 0
        self.margin = 0.33
    def speed(self):
        if self.game.highscore < 60:
            self.percent = (self.game.WPM / 60) - self.margin
        else:
            self.percent = (self.game.WPM / self.game.highscore) - self.margin

        length = self.percent * self.width
        if length < self.width * (1 -self.margin):
            color = FONTBLUE
        else:
            color = ((200,0,0))
        self.image.fill(COLORKEY)
        pygame.draw.rect(self.image,(color), [0,0,length,self.height])
        pygame.draw.rect(self.image,(self.game.textcolor), [0,0,self.width,self.height], width=6)
        pygame.draw.line(self.image, (self.game.textcolor), (self.width * (1-self.margin), 4), (self.width * (1-self.margin), self.height - 4), 4)

    def update(self):
        self.speed()
        self.dirty = 1

class Progression_bar(pygame.sprite.DirtySprite):
    def __init__(self, game):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.width = 700
        self.height = 25
        self.surface= pygame.Surface((self.width, self.height))
        self.surface.fill(COLORKEY)
        self.surface.set_colorkey(COLORKEY)
        self.image = self.surface
        self.rect = self.image.get_rect()
        self.rect.center = (self.game.width/2, 600)
        self.percent = 0
    def time(self):
        self.percent = self.game.time_elapsed / self.game.max_time
        length = self.percent * self.width
        self.image.fill(COLORKEY)
        pygame.draw.rect(self.image,(FONTBLUE), [0,0,length,self.height])
        pygame.draw.rect(self.image,(self.game.textcolor), [0,0,self.width,self.height], width=6)
    def update(self):
        self.time()
        self.dirty = 1

class Score_add(pygame.sprite.DirtySprite):
    def __init__(self, game, x, y, score, error):
        self.groups = game.hud
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.surface= pygame.Surface((50, 50))
        self.surface.fill(COLORKEY)
        self.surface.set_colorkey(COLORKEY)
        self.image = self.surface
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.alpha = 400
        self.value = score
        self.speed = 5
        self.error = error
        self.font = pygame.font.Font("resource1.ttf", 30)
        if not error:
            self.text = self.font.render("".join(["+",str(score)]), False, (self.game.selectcolor))
        else:
            self.text = self.font.render(" x", False, (FONTRED))
        self.surface.blit(self.text, (0, 0))
        self.width = self.text.get_width()

    def animation(self):
        if not self.error:
            self.rect.y -= self.speed * (self.game.dt /17)
        self.alpha -= 5 * self.speed * (self.game.dt /17)
        if self.alpha - 5 <= 0:
            self.kill()
        self.surface.set_alpha(self.alpha)
        self.image = self.surface

    def update(self):
        self.animation()
        self.dirty = 1

class TypeBox(pygame.sprite.DirtySprite):
    def __init__(self, game):
        self.groups = game.typeboxes
        pygame.sprite.DirtySprite.__init__(self, self.groups)
        self.game = game
        self.w, self.h = 200, 50
        self.font = self.game.font
        self.content = []
        self.str = ''.join(self.content)
        self.image = pygame.Surface((self.w, self.h)).convert_alpha()
        self.image.set_colorkey(COLORKEY)
        self.image.fill(COLORKEY)
        self.rect = self.image.get_rect()
        self.rect.topleft = (350,440)
        self.offset = 6
        self.cursor = pygame.Surface((3, 40)).convert_alpha()
        self.cursor_x = 10
        self.cursor_pos = 0
        Progression_bar(self.game)
        Speed_bar(self.game)

    def Type(self, key):
        self.content.append(key)
        img, rect = self.font.render(key, (self.game.textcolor))
        self.cursor_x += img.get_width() + self.game.spacement
        self.cursor_pos += 1
        if self.game.paused:
            self.game.paused = False
        if self.game.gamemode == 'letters':
            #self.submit()
            pass

    def Delete(self):
        img, rect = self.font.render(self.content[len(self.content) - 1], (self.game.textcolor))
        self.cursor_x -=  img.get_width() + self.game.spacement
        self.cursor_pos -= 1
        self.content.pop()

    def Text(self):
        lenght = 10
        for i in range(len(self.str_list)):
            img, rect = self.font.render(self.str_list[i], (self.game.textcolor))
            char_w = img.get_width()
            char_h = img.get_height()
            lenght += char_w + self.game.spacement
            if self.str_list[i] in ('g','j','p','q','y','ç',',',';','/'):
                self.offset = 6
            else:
                self.offset = 0
            self.image.blit(img.convert_alpha(),(lenght - char_w, (35 + self.offset - char_h )))

    def Cursor(self):
        self.cursor.fill(self.game.cursor_color)
        self.cursor.set_alpha(self.game.cursor_alpha)
        self.image.blit(self.cursor,(self.cursor_x, 0))

    def Submit(self):
        self.cursor_x = 10
        self.cursor_pos = 0
        self.content = []
        if ''.join(self.str_list) == self.game.words_list[self.game.cursor_pos]:
            Score_add(self.game, self.game.cursor_x + self.game.cursor.get_width()//2, 320, len(list(self.game.words_list[self.game.cursor_pos])), False)
            self.game.keys_score += len(list(self.game.words_list[self.game.cursor_pos]))
            img, rect = self.font.render(str(self.game.words_list[self.game.cursor_pos]), (self.game.textcolor))
            char_w = img.get_width()
            if self.game.cursor_pos != len(self.game.words_list) - 1:
                self.game.cursor_x += char_w + self.game.space
            else:
                self.game.cursor_x =  40 + self.game.space - self.game.cursor.get_width()
            self.game.cursor_pos += 1
        else:
            #print(''.join(self.str_list),self.game.words_list[self.game.cursor_pos])
            Score_add(self.game, self.game.cursor_x + self.game.cursor.get_width()//2, 300, len(list(self.game.words_list[self.game.cursor_pos])), True)
            self.game.cursor_color = (255,0,0)
            self.game.cursor_alpha = 255
            self.game.errors_score += len(list(self.game.words_list[self.game.cursor_pos]))

    def update(self):
        self.image.fill(self.game.bgcolor)
        self.str = ''.join(self.content)
        self.str_list = list(self.str)
        if any([True for e in (['g','j','p','q','y','ç',',',';','/']) if e in self.content]):
            self.offset = 6
        else:
            self.offset = 0
        self.Cursor()
        self.Text()
        self.rect.topleft = (350, 440)
        self.dirty = 1
        if self.game.gamemode == 'Letters' and self.content:
            self.Submit()


class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()
        self.clock = pygame.time.Clock()
        self.timer = time.time()
        self.width = 800
        self.height = 640
        self.fullscreen = False
        self.display_info = pygame.display.Info()
        self.screen = pygame.display.set_mode((self.width, self.height),RESIZABLE)

        #hwnd = pygame.display.get_wm_info()["window"]
        #win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE) | win32con.WS_EX_LAYERED)
        #win32gui.SetLayeredWindowAttributes(hwnd, win32api.RGB(*CLEAR), 0, win32con.LWA_COLORKEY)

        self.w, self.h = pygame.display.get_surface().get_size()
        self.subscreen = pygame.Surface((self.w, self.h))
        self.spacement = 3
        self.font = pygame.freetype.Font('resource2.ttf', 30)
        self.font_small = pygame.freetype.Font('resource2.ttf', 20)
        space, trash = self.font.render(' ', (0,0,0))
        self.space = space.get_width()
        self.cursor = pygame.Surface((3, 40))
        self.cursor_alpha = 255
        self.cursor_x = 40 + self.space
        self.cursor_pos = 0
        self.plusalpha = -10
        self.gamemode = 'French'
        self.theme = "Grey"
        self.bgcolor = DARKGREY
        self.textcolor = FONTWHITE
        self.statcolor = FONTRED
        self.selectcolor = FONTGREEN
        self.typedcolor = GREY
        self.cursor_color = FONTBLUE
        self.max_chars = 28
        self.mouse_pos = pygame.mouse.get_pos()
        self.chars = ['a','z','e','r','t','y','u','i','o','p','q','s','d',
                      'f','g','h','j','k','l','m','w','x','c','v','b','n'] #,'é','è','à','â','ê','û','ù']
        self.paused = True
        self.in_menu = True
        self.in_replay_menu = False
        self.keys_score = 0
        self.errors_score = 0
        self.words_score = 0
        self.ACC = 100
        self.KPM = 0
        self.WPM = 0
        self.max_time = 60
        self.time_elapsed = 0
        self.KPM_str = ''.join([str(int(self.KPM))," cpm"])
        self.WPM_str = ''.join([str(int(self.WPM))," wpm"])
        self.ACC_str = ''.join([str(int(self.ACC)),"%"," acc"])
        self.start_clicked = False
        self.event = False
        self.hud = pygame.sprite.LayeredDirty()
        self.permasprites = pygame.sprite.LayeredDirty()
        self.typeboxes = pygame.sprite.LayeredDirty()
        self.highscore = pickle.load(open("highscore.dat", "rb"))
        self.highscore_str = ''.join(["highscore: ",str(int(self.highscore)), " wpm"])
        self.themes_list = ['Grey', 'Bright', 'Dark']
        self.gamemodes_list = ['French', 'Hard', 'Letters']
        self.click = False
        self.gamemode_x = 100
        self.gamemode_y = 100
        self.theme_x = 100
        self.theme_y = 200
        self.start_x = 100
        self.start_y = 500
        self.bg = pygame.image.load('bg1.jpg').convert_alpha()
        #Background(self, self.width, self.height, self.bg)

    def replay_menu(self):
        self.font.render_to(self.subscreen, (40,40), self.KPM_str, (self.statcolor), size=0)
        self.font.render_to(self.subscreen, (40,120), self.ACC_str, (self.statcolor), size=0)
        self.font_small.render_to(self.subscreen, (550,40), self.highscore_str, (self.statcolor), size=0)
        if self.gamemode != 'Letters':
            self.font.render_to(self.subscreen, (40,80), self.WPM_str, (self.statcolor), size=0)

        Replay = self.font.render_to(self.subscreen, (200,400), 'Replay', (self.textcolor), size=0)
        Replay.topleft = (200,400)
        Menu = self.font.render_to(self.subscreen, (500,400), 'Menu', (self.textcolor), size=0)
        Menu.topleft = (500,400)

        click = pygame.mouse.get_pressed() == (1,0,0)
        buttons = [Replay, Menu]
        for button in buttons:
            if button.collidepoint((self.mouse_pos[0] / self.scale[0], self.mouse_pos[1] / self.scale[1])):
                if button == Replay:
                    Replay = self.font.render_to(self.subscreen, (200,400), 'Replay', (self.selectcolor), size=0)
                    if click:
                        self.in_replay_menu = False
                        self.stats_reset()
                        if self.gamemode == 'French':
                            self.first_list()
                        else:
                            self.new_list()
                        self.typebox = TypeBox(self)
                if button == Menu:
                    Menu = self.font.render_to(self.subscreen, (500,400), 'Menu', (self.selectcolor), size=0)
                    if click:
                        self.stats_reset()
                        self.in_replay_menu = False
                        self.in_menu = True

    def start_menu(self):
        gamemode_hover = False
        gamemode = self.font.render_to(self.subscreen, (self.gamemode_x ,self.gamemode_y), 'Gamemode:', (self.textcolor))
        gamemode_select = self.font.render_to(self.subscreen, (self.gamemode_x + 20 + gamemode.width ,self.gamemode_y), self.gamemode, (self.textcolor))
        gamemode_select.topleft = (self.gamemode_x + 20 + gamemode.width ,self.gamemode_y)
        theme_hover = False
        theme = self.font.render_to(self.subscreen, (self.theme_x,self.theme_y), 'Theme:', (self.textcolor))
        theme_select = self.font.render_to(self.subscreen, (self.theme_x + 20 + theme.width, self.theme_y), self.theme, (self.textcolor))
        theme_select.topleft = (self.theme_x + 20 + theme.width ,self.theme_y)
        start_hover = False
        start = self.font.render_to(self.subscreen, (self.start_x,self.start_y), 'Start', (self.textcolor))
        start.topleft = (self.start_x, self.start_y)
        buttons = [gamemode_select, theme_select, start]
        for button in buttons:
            if button.collidepoint((self.mouse_pos[0] / self.scale[0], self.mouse_pos[1] / self.scale[1])):
                if button == theme_select:
                    theme_hover = True
                    if self.click:
                        if self.themes_list.index(self.theme) < len(self.themes_list) - 1:
                            self.theme = self.themes_list[self.themes_list.index(self.theme) + 1]
                        else:
                            self.theme = self.themes_list[0]
                        self.themes()
                if button == gamemode_select:
                    gamemode_hover = True
                    if self.click:
                        if self.gamemodes_list.index(self.gamemode) < len(self.gamemodes_list) - 1:
                            self.gamemode = self.gamemodes_list[self.gamemodes_list.index(self.gamemode) + 1]
                        else:
                            self.gamemode = self.gamemodes_list[0]
                if button == start:
                    start_hover = True
                    if self.click:
                        if self.gamemode == "French":
                            self.first_list()
                        else:
                            self.new_list()
                        self.typebox = TypeBox(self)
                        self.start_clicked = False
                        self.in_menu = False

        if theme_hover:
            theme_select = self.font.render_to(self.subscreen, (self.theme_x + 20 + theme.width, self.theme_y), self.theme, (self.selectcolor))
        else:
            theme_select = self.font.render_to(self.subscreen, (self.theme_x + 20 + theme.width, self.theme_y), self.theme, (self.textcolor))
        if gamemode_hover:
            gamemode_select = self.font.render_to(self.subscreen, (self.gamemode_x + 20 + gamemode.width, self.gamemode_y), self.gamemode, (self.selectcolor))
        else:
            gamemode_select = self.font.render_to(self.subscreen, (self.gamemode_x + 20 + gamemode.width, self.gamemode_y), self.gamemode, (self.textcolor))
        if start_hover:
            Start = self.font.render_to(self.subscreen, (self.start_x, self.start_y), 'Start', (self.selectcolor))
        else:
            Start = self.font.render_to(self.subscreen, (self.start_x, self.start_y), 'Start', (self.textcolor))

    def start_menu_old(self):
        Select_gamemode = self.font.render_to(self.subscreen, (100,320), 'Select gamemode:', (self.textcolor))
        Select_theme = self.font.render_to(self.subscreen, (100,100), 'Select theme:', (self.textcolor))
        self.font_small.render_to(self.subscreen, (550,40), self.highscore_str, (self.textcolor), size=0)
        Start = self.font.render_to(self.subscreen, (100,500), 'Start', (self.textcolor))
        Start.topleft = (100, 500)
        Reset = self.font_small.render_to(self.subscreen, (550,60), 'Reset', (self.textcolor), size=0)

        keys = pygame.key.get_pressed()
        click = pygame.mouse.get_pressed() == (1,0,0)
        French = pygame.Rect(0, 0, 0, 0)
        Hard =  pygame.Rect(0, 0, 0, 0)
        Letters = pygame.Rect(0, 0, 0, 0)
        if self.gamemode == 'French':
            French = self.font.render_to(self.subscreen, (100, 360), 'French', (self.typedcolor))
        else:
            French = self.font.render_to(self.subscreen, (100, 360), 'French', (self.textcolor))
        if self.gamemode == 'Letters':
            Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.typedcolor))
        else:
            Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.textcolor))
        if self.gamemode == 'Hard':
            Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.typedcolor))
        else:
            Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.textcolor))

        if self.theme == 'Grey':
            Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.typedcolor))
        else:
            Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.textcolor))
        if self.theme == 'Dark':
            Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.typedcolor))
        else:
            Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.textcolor))
        if self.theme == 'Bright':
            Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.typedcolor))
        else:
            Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.textcolor))

        French.topleft = (100,360)
        Hard.topleft = (100,400)
        Letters.topleft = (100, 440)
        Grey.topleft = (100, 140)
        Dark.topleft = (100, 180)
        Bright.topleft = (100, 220)
        Reset.topleft = (550,60)
        buttons = [French, Hard, Letters, Grey, Dark, Bright, Start, Reset]

        for button in buttons:
            if button.collidepoint((self.mouse_pos[0] / self.scale[0], self.mouse_pos[1] / self.scale[1])):
                if button == French and self.gamemode != 'French':
                    French = self.font.render_to(self.subscreen, (100, 360), 'French', (self.selectcolor))
                    if click:
                        French = self.font.render_to(self.subscreen, (100, 360), 'French', (self.typedcolor))
                        new_mode = 'French'
                        self.gamemode = new_mode
                if button == Hard:
                    Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.selectcolor))
                    if click:
                        Hard = self.font.render_to(self.subscreen, (100, 400), 'Hard', (self.typedcolor))
                        new_mode = 'Hard'
                        self.gamemode = new_mode
                if button == Letters:
                    Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.selectcolor))
                    if click:
                        Letters = self.font.render_to(self.subscreen, (100, 440), 'Letters', (self.typedcolor))
                        new_mode = 'Letters'
                        self.gamemode = new_mode
                if button == Grey:
                    Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.selectcolor))
                    if click:
                        Grey = self.font.render_to(self.subscreen, (100, 140), 'Grey', (self.typedcolor))
                        self.theme = 'Grey'
                        self.themes()
                if button == Dark:
                    Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.selectcolor))
                    if click:
                        Dark = self.font.render_to(self.subscreen, (100, 180), 'Dark', (self.typedcolor))
                        self.theme = 'Dark'
                        self.themes()
                if button == Bright:
                    Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.selectcolor))
                    if click:
                        Bright = self.font.render_to(self.subscreen, (100, 220), 'Bright', (self.typedcolor))
                        self.theme = 'Bright'
                        self.themes()
                if button == Reset:
                    Reset = self.font_small.render_to(self.subscreen, (550, 60), 'Reset', (self.selectcolor))
                    if click:
                        pickle.dump(0, open("highscore.dat", "wb"))
                        self.highscore = 0
                        self.highscore_str = ''.join(["highscore: ",str(int(self.highscore)), " wpm"])
                if button == Start:
                    Start = self.font.render_to(self.subscreen, (100, 500), 'Start', (self.selectcolor))
                    if click:
                        self.start_clicked = True
                        Start = self.font.render_to(self.subscreen, (100, 500), 'Start', (self.typedcolor))
                    if not click and self.start_clicked:
                        if self.gamemode == "French":
                            self.first_list()
                        else:
                            self.new_list()
                        self.typebox = TypeBox(self)
                        self.start_clicked = False
                        self.in_menu = False

    def themes(self):
            if self.theme == 'Bright':
                self.textcolor = GREY
                self.statcolor = GREY
                self.typedcolor = LIGHTGREY
                self.selectcolor = FONTBLUE
                self.bgcolor = WHITE
                self.cursor_color = FONTBLUE
            if self.theme == "Dark":
                self.textcolor = WHITE
                self.statcolor = WHITE
                self.typedcolor = GREY
                self.selectcolor = FONTRED
                self.bgcolor = BLACK
                self.cursor_color = WHITE
            if self.theme == "Grey":
                self.textcolor = FONTWHITE
                self.statcolor = FONTRED
                self.typedcolor = GREY
                self.selectcolor = FONTGREEN
                self.bgcolor = ATOM
                self.cursor_color = FONTBLUE

    def stats_reset(self):
        self.paused = True
        self.keys_score = 0
        self.errors_score = 0
        self.words_score = 0
        self.ACC = 100
        self.KPM = 0
        self.WPM = 0
        self.time_elapsed = 0
        self.cursor_x = 40 + self.space
        self.cursor_pos = 0

    def first_list(self):
        if self.gamemode == 'French':
            self.words_list = []
            self.next_list = []
            self.max_chars = 40
            for i in range(10):
                word = random.choice(FR_WORDS)
                if len(list(' '.join(self.words_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.words_list.append(word)
                word = random.choice(FR_WORDS)
                if len(list(' '.join(self.next_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.next_list.append(word)
            self.spacement = 3
            self.words_str = ' '.join(self.words_list)
            self.next_str = ' '.join(self.next_list)
            self.chars_list = list(self.words_str)
            self.cursor_pos = 0
            self.cursor_x = 40 + self.space

    def new_list(self):
        self.words_list = []
        self.next_list = []
        if self.gamemode == 'French':
            self.words_list = self.next_list
            self.next_list = []
            self.max_chars = 40
            for i in range(10):
                word = random.choice(FR_WORDS)
                if len(list(' '.join(self.next_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.next_list.append(word)
            self.words_str = ' '.join(self.words_list)
            self.next_str = ' '.join(self.next_list)

        if self.gamemode == 'Letters':
            self.max_chars = 20
            for i in range(self.max_chars):
                letter = random.choice(self.chars)
                self.words_list.append(letter)
            self.words_str = ''.join(self.words_list)
            self.spacement = 20

        if self.gamemode == 'Hard':
            for i in range(10):
                word = ''.join(random.sample(self.chars, k = random.randint(3,8)))
                self.max_chars = 40
                if len(list(' '.join(self.words_list))) + len(list(word)) + 1 <= self.max_chars:
                    self.words_list.append(word)
            self.words_str = ' '.join(self.words_list)
            self.spacement = 3

        self.chars_list = list(self.words_str)
        self.cursor_pos = 0
        self.cursor_x = 40 + self.space

    def stats(self):
        if self.paused:
            self.timer = time.time()
            self.time_left = self.max_time
        if not self.paused:
            self.time_elapsed = time.time() - self.timer
            self.time_left = self.max_time - self.time_elapsed
            if self.time_elapsed != 0:
                self.KPM = (self.keys_score / self.time_elapsed) * 60
                self.WPM = ((self.keys_score/5) / self.time_elapsed) * 60
        if (self.keys_score + self.errors_score) >= 1:
            self.ACC = (self.keys_score/(self.keys_score + self.errors_score)) * 100

        if self.time_left <= 0:
            if self.WPM > self.highscore:
                self.highscore = self.WPM
                self.highscore_str = ''.join(["highscore: ",str(int(self.highscore)), " wpm"])
                pickle.dump(self.WPM, open("highscore.dat","wb"))
            for sprite in self.hud:
                sprite.kill()
            self.in_replay_menu = True
            self.replay_menu()
        else:
            if not self.paused:
                self.KPM_str = ''.join([str(int(self.KPM))," cpm"])
                self.WPM_str = ''.join([str(int(self.WPM))," wpm"])
                self.ACC_str = ''.join([str(int(self.ACC)),"%"," acc"])
                self.highscore_str = ''.join(["highscore: ",str(int(self.highscore))," wpm"])

    def get_scale(self):
        self.scale = self.screen.get_size()[0] / self.width, self.screen.get_size()[1] / self.height

    def update(self):
            pygame.display.flip()
            self.subscreen.fill(self.bgcolor)
            actual_fps = self.clock.get_fps()
            pygame.display.set_caption(str(actual_fps))
            self.dt = self.clock.tick(MAXFPS)
            self.mouse_pos = pygame.mouse.get_pos()
            if not self.in_menu:
                if self.cursor_alpha >= 255:
                    self.plusalpha = -10
                if self.cursor_alpha <= 0:
                    self.plusalpha = 10
                    if self.theme != 'Dark':
                        self.cursor_color = FONTBLUE
                    else:
                        self.cursor_color = WHITE
                self.cursor_alpha += self.plusalpha * (self.dt /17)
                if self.cursor_pos == len(self.words_list):
                    self.keys_score += len(list(self.words_list[self.cursor_pos - 1])) #ERROR INDEX OUT OF RANGE
                    self.new_list()
                    if self.time_elapsed != 0:
                        self.WPM = ((self.keys_score/5) / self.time_elapsed) * 60

    def events(self):
        self.click = False
        for event in pygame.event.get():
            self.event = event
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.click = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if not self.in_menu:
                        self.stats_reset()
                        self.typebox.kill()
                        self.in_menu = True
                    else:
                        pygame.quit()
                if not self.in_menu and not self.in_replay_menu:
                    if event.key != pygame.K_BACKSPACE:
                        if event.key == pygame.K_SPACE:
                            self.typebox.Submit()
                            self.cursor_alpha = 255
                        else:
                            self.typebox.Type(event.unicode)
                    else:
                        if self.typebox.content:
                            self.typebox.Delete()
                            self.errors_score += 1

                elif event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.w = self.display_info.current_w
                        self.h = self.display_info.current_h
                        os.environ['SDL_VIDEO_WINDOW_POS']='%d,%d' %(0,0)
                        self.screen = pygame.display.set_mode((self.w, self.h),NOFRAME)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.w, self.h = self.width, self.height
                        os.environ['SDL_VIDEO_WINDOW_POS']='%d,%d' %(0,0)
                        self.screen = pygame.display.set_mode((self.width, self.height,),RESIZABLE)

            elif event.type == pygame.VIDEORESIZE:
                scrsize = event.size
                self.w   = event.w
                self.h   = event.h
                self.screen = pygame.display.set_mode(scrsize,RESIZABLE)

    def draw(self):
        if self.cursor_pos < len(self.words_list):
            cursor, trash = self.font.render(self.words_list[self.cursor_pos], (self.textcolor))
            self.cursor = pygame.Surface((cursor.get_width() + 10, 40))
            self.cursor.fill(COLORKEY)
            self.cursor.set_colorkey(COLORKEY)
            pygame.draw.rect(self.cursor, self.cursor_color, (0, 0, cursor.get_width() + 10, 40))
            self.cursor.set_alpha(self.cursor_alpha // 2)
            self.subscreen.blit(self.cursor,(self.cursor_x - 5, (self.subscreen.get_height()//2)-3))

        lenght = 40
        for i in range(len(self.words_list)):
            if self.cursor_pos > i:
                color = self.typedcolor
            else:
                color = self.textcolor
            img, rect = self.font.render(self.words_list[i], (color))
            char_w = img.get_width()
            char_h = img.get_height()
            lenght += char_w + self.space
            if any([True for e in (['g','j','p','q','y','ç',',',';','/']) if e in list(self.words_list[i])]):
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 35 - char_h ))
            else:
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 29 - char_h ))

        lenght = 40
        for i in range(len(self.next_list)):
            img, rect = self.font.render(self.next_list[i], (self.textcolor))
            char_w = img.get_width()
            char_h = img.get_height()
            lenght += char_w + self.space
            if any([True for e in (['g','j','p','q','y','ç',',',';','/']) if e in list(self.next_list[i])]):
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 40 + 35 - char_h ))
            else:
                self.subscreen.blit(img,(lenght - char_w, (self.subscreen.get_height()//2) + 40 + 29 - char_h ))




        self.KPM_img = self.font.render_to(self.subscreen, (40,40), self.KPM_str, (self.statcolor), size=0)
        if self.gamemode != 'Letters':
            self.WPM_img = self.font.render_to(self.subscreen, (40,80), self.WPM_str, (self.statcolor), size=0)
        self.ACC_img = self.font.render_to(self.subscreen, (40,120), self.ACC_str, (self.statcolor), size=0)
        if self.time_left>= 0:
            self.time_img = self.font.render_to(self.subscreen, (40,160), str(round(self.time_left, 2)), (self.statcolor), size=0)
            self.time_img.bottom = 170
        self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))

    def loop(self):
        while True:
            self.get_scale()
            self.update()
            self.events()
            self.permasprites.update()
            self.permasprites.draw(self.subscreen)
            if not self.in_menu and not self.in_replay_menu:
                self.stats()
                if self.gamemode != 'Letters':
                    self.typeboxes.draw(self.subscreen)
                self.hud.draw(self.subscreen)
                self.draw()
                self.hud.update()
                self.typeboxes.update()
            if self.in_menu:
                self.start_menu()
                self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))
            if self.in_replay_menu:
                self.replay_menu()
                self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))

g = Game()
while True:
    g.loop()
