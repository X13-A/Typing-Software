import pygame
import pygame.freetype
import sys
from os import path
import random
import time
from pygame.locals import *
WHITE      = (255,255,255)
LIGHTGREY  = (230,230,230)
BLACK      = (0,0,0)
HIGHLIGHT  = (44,49,60)
GREY       = (40,44,52)
DARKGREY   = (63,67,73)
FONTWHITE  = (171,178,191)
FONTRED    = (224,108,117)
FONTBLUE   = (97,175,239)
FONTGREEN  = (152,195,121)
FONTPURPLE = (198,120,221)
MAXFPS     = 60

class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()
        self.clock = pygame.time.Clock()
        self.timer = time.time()
        self.width = 800
        self.height = 640
        self.screen = pygame.display.set_mode((self.width, self.height,),RESIZABLE)
        self.w, self.h = pygame.display.get_surface().get_size()
        self.subscreen = pygame.Surface((self.w, self.h))
        self.cursor = pygame.Surface((3, 35))
        self.cursor_alpha = 255
        self.plusalpha = -10
        self.bgcolor = GREY
        self.textcolor = FONTWHITE
        self.statcolor = FONTRED
        self.typedcolor = DARKGREY
        self.theme = "Dark"
        self.font = pygame.freetype.Font('resource1.ttf', 30)
        self.chars = ['a','z','e','r','t','y','u','i','o','p','q','s','d',
                      'f','g','h','j','k','l','m','w','x','c','v','b','n'] #,'é','è','à','â','ê','û','ù']


        self.sentence_str = ' '.join([''.join(random.sample(self.chars, k = random.randint(1,8))),
                                      ''.join(random.sample(self.chars, k = random.randint(1,8))),
                                      ''.join(random.sample(self.chars, k = random.randint(1,8))),
                                      ''.join(random.sample(self.chars, k = random.randint(1,8))),
                                      ''.join(random.sample(self.chars, k = random.randint(1,8))),
                                      ''.join(random.sample(self.chars, k = random.randint(1,8)))])

        self.sentence_list = list(self.sentence_str)
        self.typed_str = ''
        self.typed_list = []
        self.keys_score = 0
        self.errors_score = 0
        self.words_score = 0
        self.ACC = 100
        self.KPM = 0
        self.WPM = 0

    def stats(self):
        self.time = time.time() - self.timer
        if (self.keys_score + self.errors_score) >= 1:
            self.ACC = (self.keys_score/(self.keys_score + self.errors_score)) * 100
        self.KPM_str = ''.join([str(int(self.KPM))," cpm"])
        self.WPM_str = ''.join([str(int(self.WPM))," wpm"])
        self.ACC_str = ''.join([str(int(self.ACC)),"%"," acc"])

    def update(self):
            pygame.display.flip()
            self.subscreen.fill(self.bgcolor)
            actual_fps = self.clock.get_fps()
            pygame.display.set_caption(str(actual_fps))
            self.dt = self.clock.tick(MAXFPS)
            if self.cursor_alpha >= 255:
                self.plusalpha = -10
            if self.cursor_alpha <= 0:
                self.plusalpha = 10
            self.cursor_alpha += self.plusalpha * (self.dt /17)
    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    if self.theme == "Bright":
                        self.theme = "Dark"
                        self.textcolor = FONTWHITE
                        self.statcolor = FONTRED
                        self.typedcolor = DARKGREY
                        self.bgcolor = GREY

                    elif self.theme == "Dark":
                        self.theme = "Bright"
                        self.textcolor = DARKGREY
                        self.statcolor = DARKGREY
                        self.typedcolor = LIGHTGREY
                        self.bgcolor = WHITE

                if event.unicode == self.sentence_list[0]:
                    self.sentence_list.pop(0)
                    self.sentence_str = ''.join(self.sentence_list)
                    self.keys_score += 1
                    self.KPM = (self.keys_score / self.time) * 60
                    self.typed_list.append(event.unicode)
                    self.typed_str = ''.join(self.typed_list)
                    if len(self.typed_list) >= 50:
                        self.typed_list.pop(0)

                    if event.unicode == ' ':
                        self.words_score += 1
                        self.WPM = (self.words_score / self.time) * 60
                        self.sentence_list.append(' ')
                        for l in random.sample(self.chars, k = random.randint(1,8)):
                            self.sentence_list.append(l)
                        self.sentence_str = ''.join(self.sentence_list)
                else:
                    self.errors_score += 1

            if event.type == pygame.VIDEORESIZE:
                scrsize = event.size
                self.w   = event.w
                self.h   = event.h
                self.screen = pygame.display.set_mode(scrsize,RESIZABLE)

    def draw(self):
        self.sentence_img, sentecerect = self.font.render(self.sentence_str, (self.textcolor))
        self.subscreen.blit(self.sentence_img,(self.subscreen.get_width() // 2, self.subscreen.get_height()//2))
        self.typed_img, typedrect = self.font.render(self.typed_str, (self.typedcolor))
        self.subscreen.blit(self.typed_img,(self.subscreen.get_width() // 2 - 4 - typedrect.width, self.subscreen.get_height()//2))
        self.cursor.fill(FONTBLUE)
        self.cursor.set_alpha(self.cursor_alpha)
        self.subscreen.blit(self.cursor,(self.subscreen.get_width() // 2 - self.cursor.get_width(), (self.subscreen.get_height()//2)-4))
        self.KPM_img = self.font.render_to(self.subscreen, (40,40), self.KPM_str, (self.statcolor), size=0)
        self.WPM_img = self.font.render_to(self.subscreen, (40,80), self.WPM_str, (self.statcolor), size=0)
        self.ACC_img = self.font.render_to(self.subscreen, (40,120), self.ACC_str, (self.statcolor), size=0)
        self.screen.blit(pygame.transform.scale(self.subscreen,(self.w, self.h)),(0,0))
    def loop(self):
        while True:
            self.events()
            self.update()
            self.stats()
            self.draw()

g = Game()
while True:
    g.loop()
